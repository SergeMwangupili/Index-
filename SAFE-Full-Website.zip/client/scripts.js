document.getElementById('registrationForm')?.addEventListener('submit', async function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    const jsonData = {};
    formData.forEach((value, key) => jsonData[key] = value);

    if (jsonData.password !== jsonData.confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    const response = await fetch('/api/register', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(jsonData)
    });

    const result = await response.json();
    alert(result.message || 'Registration completed');
});
