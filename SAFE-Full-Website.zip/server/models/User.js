const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    firstName: String,
    middleName: String,
    surname: String,
    age: Number,
    sex: String,
    nationalId: String,
    email: { type: String, unique: true },
    contact: String,
    password: String
});

module.exports = mongoose.model('User', UserSchema);
