# SAFE - See All Future Earnings

## Installation & Setup

### Requirements:
- Node.js & npm
- MongoDB

### Steps to Run:

1. Clone the repository or unzip the folder.
2. Run `npm install` inside the `server/` directory.
3. Make sure MongoDB is running locally.
4. Create a `.env` file in the root of the project with:
```
MONGO_URI=mongodb://localhost:27017/safe-db
```
5. Run the server with:
```
npm start
```
6. Open `client/index.html` in your browser to use the site.

### Deployment (Optional):
You can deploy the frontend on Netlify and the backend on Heroku.

